'''
score=80
if score<=60:
    print("成绩不太理想")
    pass
print("语句运行结束")
score=int(input('qing..'))
if score>90:
    print('..')
    pass
elif score>=88:
    print('...')
    pass
else:
    print('///')
'''
''''
count=1
while count<=10:
    
import random
person=int(input('请出拳：[0:石头 1:剪刀 2:布]'))
computer=random.randint(0,2)
if person==0 and computer==1:
    print('你赢了')
    pass
elif person==1 and computer==2:
    print('你赢了')
    pass
elif person==2 and computer==0:
    print('你赢了')
    pass
elif person==computer:
    print('平了')
else:
    print('你输了')
'''
'''
xuefen=int(input('请输入您的学分'))
grade=int(input("请输入您的成绩"))
if xuefen>=10:
    if grade>=80:
      print('您的成绩也太好了吧')
      pass
    else:
        print('优秀')
        pass
else:
    print('您的成绩也太差了')

'''
'''''''''
row=9
while row>=1:
     col=1
     while col<=row:
         print("%d*%d=%d"%(row,col,row*col),end=" ")
         col+=1
         pass
     print()
     row-=1
     pass
'''''
row=1
while row<=5:
    j=1
    while j<=5-row:
         print(' ',end='')#执行四次（for函数）
         j+=1
         pass
    k=1
    while k<=2*row-1:
        print('*',end="")
        k+=1
        pass
    print()
    row+=1



