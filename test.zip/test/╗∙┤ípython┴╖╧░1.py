print("hello python")
a=10
a='吴老师'
print(type(a))
print(a)#先定义变量，才能使用变量
qq=66666
shoujihao=502433
gsdz="广州市白云区"
print("我的QQ是%s, 我的手机号是%s, 我的公司地址是%s"%(qq,shoujihao,gsdz))